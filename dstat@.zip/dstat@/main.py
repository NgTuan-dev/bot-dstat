import asyncio
import json
import os
import uuid
from datetime import datetime
from urllib.parse import urlparse
import httpx
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes

# Admin and chat configuration
ADMIN_IDS = [7891226746, 7891226746]
ALLOWED_CHAT_ID = -4683404076

# Language-specific messages
MESSAGES = {
    "en": {
        "choose_dstat": "Choose Dstat Type 📊",
        "choose_server": "Select a Server to Start Dstat 📡",
        "server_in_use": "This server is currently in use by another user. Please select a different server.",
        "already_running": "You are already running a Dstat session. Please complete it before starting another.",
        "no_data": "No data available to display.",
        "error_summary": "An error occurred while generating the summary.",
        "server_not_found": "Server information not found.",
        "logs_not_found": "No attack logs found.",
        "lang_set": "Language set to English 🇺🇸",
    },
    "vi": {
        "choose_dstat": "Chọn Loại Dstat 📊",
        "choose_server": "Chọn Server để Bắt Đầu Dstat 📡",
        "server_in_use": "Server này đang được người khác sử dụng. Vui lòng chọn server khác.",
        "already_running": "Bạn đang chạy một phiên Dstat. Vui lòng hoàn thành trước khi bắt đầu phiên mới.",
        "no_data": "Không có dữ liệu để hiển thị.",
        "error_summary": "Có lỗi xảy ra khi tạo báo cáo tổng kết.",
        "server_not_found": "Không tìm thấy thông tin server.",
        "logs_not_found": "Không tìm thấy bản ghi tấn công.",
        "lang_set": "Ngôn ngữ được đặt thành Tiếng Việt 🇻🇳",
    }
}

def format_data_rate(kbps):
    """Format data rate into TB/s, GB/s, MB/s, or KB/s."""
    if kbps >= 1024**3:
        return f"{kbps / 1024**3:.1f} TB/s"
    elif kbps >= 1024**2:
        return f"{kbps / 1024**2:.1f} GB/s"
    elif kbps >= 1024:
        return f"{kbps / 1024:.1f} MB/s"
    else:
        return f"{kbps:.1f} KB/s"

def format_number(number):
    """Format large numbers with K, M suffixes."""
    if number >= 1000000:
        return f"{number / 1000000:.1f}M"
    elif number >= 1000:
        return f"{number / 1000:.1f}K"
    return str(number)

def save_running_server(user_id, server_name):
    """Save the server a user is currently using."""
    running_servers = load_all_running_servers()
    running_servers[str(user_id)] = server_name
    with open('server_running.json', 'w') as file:
        json.dump(running_servers, file, indent=4)

def remove_running_server(user_id):
    """Remove a user from the running servers list."""
    running_servers = load_all_running_servers()
    if str(user_id) in running_servers:
        del running_servers[str(user_id)]
        with open('server_running.json', 'w') as file:
            json.dump(running_servers, file, indent=4)

def load_all_running_servers():
    """Load all running servers from file."""
    try:
        with open('server_running.json', 'r') as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def load_running_server(user_id):
    """Load the server a specific user is running."""
    return load_all_running_servers().get(str(user_id))

def is_user_subscribed(user_id):
    """Check if a user is subscribed."""
    try:
        with open("sub_users.json", "r") as file:
            subscribed_users = json.load(file)
    except FileNotFoundError:
        subscribed_users = []
    return user_id in subscribed_users

def add_user_to_subscribed(user_id):
    """Add a user to the subscribed list."""
    subscribed_users = load_subscribed_users()
    if user_id not in subscribed_users:
        subscribed_users.append(user_id)
        with open("sub_users.json", "w") as file:
            json.dump(subscribed_users, file, indent=4)

def load_subscribed_users():
    """Load subscribed users from file."""
    try:
        with open("sub_users.json", "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_user_language(user_id, language):
    """Save a user's preferred language."""
    try:
        with open('user_languages.json', 'r+') as file:
            data = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}
    data[str(user_id)] = language
    with open('user_languages.json', 'w') as file:
        json.dump(data, file, indent=4)

def load_user_language(user_id):
    """Load a user's preferred language."""
    try:
        with open('user_languages.json', 'r') as file:
            data = json.load(file)
            return data.get(str(user_id), "en")
    except (FileNotFoundError, json.JSONDecodeError):
        return "en"

def save_data(user_id, key, value):
    """Save data to a user's JSON file."""
    file_path = f"{user_id}_data.json"
    try:
        with open(file_path, 'r+') as file:
            try:
                data = json.load(file)
            except json.JSONDecodeError:
                data = {}
            data[key] = value
            file.seek(0)
            json.dump(data, file, indent=4)
            file.truncate()
    except FileNotFoundError:
        with open(file_path, 'w') as file:
            json.dump({key: value}, file, indent=4)

def load_data(user_id, key):
    """Load data from a user's JSON file."""
    file_path = f"{user_id}_data.json"
    try:
        with open(file_path, 'r') as file:
            try:
                data = json.load(file)
                return data.get(key)
            except json.JSONDecodeError:
                return None
    except FileNotFoundError:
        return None

def save_log(user_id, server_name, rps, dstat_id):
    """Save a log entry for a Dstat session."""
    log_file = f"{user_id}_logs.json"
    log_entry = {
        'datetime': datetime.now().isoformat(),
        'server': server_name,
        'rps': rps,
        'dstat_id': dstat_id
    }
    try:
        with open(log_file, 'r+') as file:
            logs = json.load(file)
            logs.append(log_entry)
            file.seek(0)
            json.dump(logs, file, indent=4)
    except FileNotFoundError:
        with open(log_file, 'w') as file:
            json.dump([log_entry], file, indent=4)

def save_global_log(user_id, server_name, max_rps, total_rps, dstat_id):
    """Save a global log entry for admin review."""
    log_entry = {
        'user_id': user_id,
        'server': server_name,
        'max_rps': max_rps,
        'total_rps': total_rps,
        'dstat_id': dstat_id,
        'timestamp': datetime.now().isoformat()
    }
    try:
        with open('global_dstat_logs.json', 'r+') as file:
            logs = json.load(file)
            logs.append(log_entry)
            file.seek(0)
            json.dump(logs, file, indent=4)
    except FileNotFoundError:
        with open('global_dstat_logs.json', 'w') as file:
            json.dump([log_entry], file, indent=4)

async def fetch_nginx_status(update, server_url):
    """Fetch total requests from Nginx status endpoint."""
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            response = await client.get(server_url)
            if response.status_code == 200:
                parts = response.text.split(" ")
                if len(parts) > 9:  # Ensure correct field exists
                    return int(parts[9].strip())
                return None
            return None
        except Exception as e:
            print(f"Error fetching Nginx status: {e}")
            return None

async def update_user_data(update, context, server_url, start_time, dstat_id):
    """Update and display Dstat request counts."""
    user_id = update.callback_query.from_user.id
    chat_id = update.callback_query.message.chat_id
    language = load_user_language(user_id)
    session_baseline = load_data(user_id, 'session_baseline')
    previous_value = load_data(user_id, 'previous_value')
    differences = load_data(user_id, 'differences') or []
    message_ids = load_data(user_id, 'message_ids') or []

    try:
        new_value = await fetch_nginx_status(update, server_url)
        if new_value is None:
            difference = 0
            differences.append(difference)
            save_data(user_id, 'differences', differences)
            save_data(user_id, 'message_ids', message_ids)
            save_log(user_id, server_url, difference, dstat_id)
            return

        # Initialize session baseline
        if session_baseline is None:
            session_baseline = new_value
            save_data(user_id, 'session_baseline', session_baseline)
            difference = 0
            previous_value = new_value
        else:
            if previous_value is not None:
                difference = max(0, new_value - previous_value)
                differences.append(difference)
            previous_value = new_value

        # Calculate total requests relative to baseline
        total_difference = max(0, new_value - session_baseline)
        elapsed_time = int((datetime.now() - start_time).total_seconds())

        # Create dynamic update message
        progress_bar = "█" * min(elapsed_time // 2, 10) + "▒" * (10 - min(elapsed_time // 2, 10))
        message_text = (
            f"<b>🌐 Dstat in Progress...</b>\n"
            f"<code>Server:</code> <b>{server_url.split('/')[-2]}</b>\n"
            f"<code>Requests/s:</code> <b>{difference:,}</b>\n"
            f"<code>Total Requests:</code> <b>{total_difference:,}</b>\n"
            f"<code>Elapsed:</code> <b>{elapsed_time}s</b> [{progress_bar}]\n"
            f"<code>Dstat ID:</code> <b>{dstat_id}</b>"
        )

        # Send and delete message
        message = await context.bot.send_message(chat_id=chat_id, text=message_text, parse_mode='HTML')
        message_ids.append(message.message_id)
        await asyncio.sleep(4)
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=message.message_id)
            message_ids.remove(message.message_id)
        except:
            pass

        # Save data
        save_data(user_id, 'previous_value', new_value)
        save_data(user_id, 'differences', differences)
        save_data(user_id, 'message_ids', message_ids)
        save_data(user_id, 'session_baseline', session_baseline)
        save_log(user_id, server_url, difference, dstat_id)

    except Exception as e:
        print(f"Error in update_user_data: {e}")
        differences.append(0)
        save_data(user_id, 'differences', differences)
        save_data(user_id, 'message_ids', message_ids)
        save_log(user_id, server_url, 0, dstat_id)

def create_summary_message(language, server_name, max_difference, total_difference, average_difference, timestamp, user_mention, dstat_id):
    """Create a formatted Dstat summary message."""
    if language == "vi":
        return (
            f"<b>╔══════════════════════╗</b>\n"
            f"<b>🏝️ Dstat Tổng Kết: {server_name} 🏝️</b>\n"
            f"<b>╚══════════════════════╝</b>\n"
            f"<b>⏱️ Đỉnh Cao Requests/s:</b> <code>{max_difference:,}</code>\n"
            f"<b>📊 Trung Bình Requests/s:</b> <code>{average_difference:,}</code>\n"
            f"<b>🔢 Tổng Requests:</b> <code>{total_difference:,}</code>\n"
            f"<b>📅 Ngày:</b> <code>{timestamp}</code>\n"
            f"<b>👤 Người Dùng:</b> <code>{user_mention}</code>\n"
            f"<b>🆔 Dstat ID:</b> <code>{dstat_id}</code>\n"
            f"<i>🔥 Powered by DstatCountBot 🔥</i>"
        )
    return (
        f"<b>╔══════════════════════╗</b>\n"
        f"<b>🏝️ Dstat Summary: {server_name} 🏝️</b>\n"
        f"<b>╚══════════════════════╝</b>\n"
        f"<b>⏱️ Peak Requests/s:</b> <code>{max_difference:,}</code>\n"
        f"<b>📊 Average Requests/s:</b> <code>{average_difference:,}</code>\n"
        f"<b>🔢 Total Requests:</b> <code>{total_difference:,}</code>\n"
        f"<b>📅 Date:</b> <code>{timestamp}</code>\n"
        f"<b>👤 User:</b> <code>{user_mention}</code>\n"
        f"<b>🆔 Dstat ID:</b> <code>{dstat_id}</code>\n"
        f"<i>🔥 Powered by DstatCountBot 🔥</i>"
    )

async def summary_and_cleanup(update, context, server_name):
    """Generate and send Dstat summary, then clean up."""
    user_id = update.callback_query.from_user.id
    chat_id = update.callback_query.message.chat_id
    language = load_user_language(user_id)
    differences = load_data(user_id, 'differences') or []
    message_ids = load_data(user_id, 'message_ids') or []
    timestamp = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
    dstat_id = load_data(user_id, 'dstat_id') or str(uuid.uuid4())

    try:
        # Generate summary
        if differences:
            max_difference = max(differences)
            total_difference = sum(differences)
            average_difference = round(total_difference / len(differences), 2) if differences else 0
            user_mention = update.callback_query.from_user.first_name
            summary_message = create_summary_message(
                language, server_name, max_difference, total_difference, average_difference,
                timestamp, user_mention, dstat_id
            )

            # Save performance
            user_name = update.callback_query.from_user.username
            full_name = update.callback_query.from_user.full_name or "Unknown"
            if user_name:
                save_user_performance(user_name, full_name, max_difference, total_difference, server_name)
                save_global_log(user_id, server_name, max_difference, total_difference, dstat_id)
            else:
                print(f"Skipping save_user_performance for user_id {user_id}: no username")

            await context.bot.send_message(chat_id=chat_id, text=summary_message, parse_mode='HTML')
        else:
            await context.bot.send_message(chat_id=chat_id, text=MESSAGES[language]["no_data"], parse_mode='HTML')

        # Clean up messages
        for msg_id in message_ids:
            try:
                await context.bot.delete_message(chat_id=chat_id, message_id=msg_id)
            except Exception as e:
                print(f"Error deleting message {msg_id}: {e}")

        # Clean up files and state
        try:
            remove_running_server(user_id)
            for file in [f"{user_id}_data.json", f"{user_id}_logs.json"]:
                if os.path.exists(file):
                    os.remove(file)
        except Exception as e:
            print(f"Error cleaning up files: {e}")

    except Exception as e:
        print(f"Error in summary_and_cleanup: {e}")
        await context.bot.send_message(chat_id=chat_id, text=MESSAGES[language]["error_summary"], parse_mode='HTML')

def save_user_performance(user_name, full_name, max_requests, total_requests, server_name):
    """Save user performance data."""
    if not user_name:
        print(f"Skipping save_user_performance: user_name is missing")
        return
    user_key = f"{user_name}[¥]{full_name or 'Unknown'}"
    try:
        with open('user_performance.json', 'r+') as file:
            try:
                data = json.load(file)
            except json.JSONDecodeError:
                data = {}
            if user_key not in data:
                data[user_key] = {}
            if server_name not in data[user_key]:
                data[user_key][server_name] = {'max': max_requests, 'total': total_requests}
            else:
                old_avg = (data[user_key][server_name]['max'] + data[user_key][server_name]['total']) / 2
                new_avg = (max_requests + total_requests) / 2
                if new_avg > old_avg:
                    data[user_key][server_name]['max'] = max_requests
                    data[user_key][server_name]['total'] = total_requests
            file.seek(0)
            json.dump(data, file, indent=4)
            file.truncate()
    except FileNotFoundError:
        with open('user_performance.json', 'w') as file:
            json.dump({user_key: {server_name: {'max': max_requests, 'total': total_requests}}}, file, indent=4)

async def handle_stats(update: Update, context: ContextTypes.DEFAULT_TYPE, server_info):
    """Handle a Layer 7 Dstat session."""
    user_id = update.callback_query.from_user.id
    chat_id = update.effective_chat.id
    language = load_user_language(user_id)
    dstat_id = str(uuid.uuid4())
    save_data(user_id, 'dstat_id', dstat_id)
    start_time = datetime.now()

    # Run Dstat for 14 seconds
    for _ in range(14):
        await update_user_data(update, context, server_info['url'], start_time, dstat_id)
        await asyncio.sleep(1)

    await summary_and_cleanup(update, context, server_info['name'])
    remove_running_server(user_id)

async def count(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /dstat command."""
    language = load_user_language(update.effective_user.id)
    keyboard = [
        [InlineKeyboardButton("Layer 7 Dstat", callback_data="layer7_dstat")],
        [InlineKeyboardButton("Ranking", callback_data="layer7_dstat_top")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    message_text = MESSAGES[language]["choose_dstat"]
    if update.callback_query:
        await update.callback_query.message.edit_text(message_text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(message_text, reply_markup=reply_markup)

async def show_servers(update: Update, context: ContextTypes.DEFAULT_TYPE, servers, server_type):
    """Show available servers for Dstat."""
    language = load_user_language(update.effective_user.id)
    max_button_length = max(len(server['name']) for server in servers)
    columns = 1 if max_button_length > 13 else 2
    keyboard = []
    row = []
    for server in servers:
        row.append(InlineKeyboardButton(f"🛡 {server['name']} 🛡", callback_data=f"{server_type}count_{server['name']}"))
        if len(row) == columns:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    keyboard.append([InlineKeyboardButton("<< Back", callback_data="back_to_dstatcount_type")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text(MESSAGES[language]["choose_server"], reply_markup=reply_markup, parse_mode='HTML')

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button callbacks."""
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = update.effective_user.id
    language = load_user_language(user_id)

    if data == "layer7_dstat":
        servers = load_servers()
        await show_servers(update, context, servers, "layer7")
        return

    if data.startswith("layer7count_"):
        server_name = data.split("layer7count_")[1]
        servers = load_servers()
        server_info = next((server for server in servers if server['name'] == server_name), None)
        if server_info is None:
            await query.edit_message_text(MESSAGES[language]["server_not_found"], parse_mode='HTML')
            return

        current_server = load_running_server(user_id)
        if current_server:
            await query.edit_message_text(MESSAGES[language]["already_running"], parse_mode='HTML')
            return
        if server_name in load_all_running_servers().values():
            await query.edit_message_text(MESSAGES[language]["server_in_use"], parse_mode='HTML')
            return

        chat_id = update.effective_chat.id
        parsed_url = urlparse(server_info['url'])
        simplified_url = f"{parsed_url.scheme}://{parsed_url.netloc}/"
        message_text = (
            f"<b>🏝️ Dstat Started: {server_info['name']} 🏝️</b>\n"
            f"<code>Target:</code> <b>{simplified_url}</b>\n"
            f"<code>Protection:</code> <b>{server_info['protection_type']}</b>\n"
            f"<code>Duration:</code> <b>120 Seconds</b>"
        )
        save_running_server(user_id, server_name)
        await context.bot.send_message(chat_id=chat_id, text=message_text, parse_mode='HTML')
        asyncio.create_task(handle_stats(update, context, server_info))

def load_servers():
    """Load server configurations."""
    try:
        with open('servers.json', 'r') as file:
            data = json.load(file)
            return data.get('servers', [])
    except FileNotFoundError:
        return []

async def add_server(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Add a new server (admin only)."""
    if update.effective_user.id not in ADMIN_IDS:
        return
    args = context.args
    if len(args) != 3:
        await update.message.reply_text("Usage: /add <name> <nginx_status_url> <protection_type>")
        return
    new_server = {
        "name": args[0],
        "url": args[1],
        "protection_type": args[2]
    }
    try:
        with open('servers.json', 'r+') as file:
            data = json.load(file)
            data["servers"].append(new_server)
            file.seek(0)
            json.dump(data, file, indent=4)
            file.truncate()
    except FileNotFoundError:
        with open('servers.json', 'w') as file:
            json.dump({"servers": [new_server]}, file, indent=4)
    await update.message.reply_text(f"Server {args[0]} added successfully!")

async def remove_server(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Remove a server (admin only)."""
    if update.effective_user.id not in ADMIN_IDS:
        return
    args = context.args
    if len(args) != 1:
        await update.message.reply_text("Usage: /rm <server_name>")
        return
    server_name = args[0]
    servers = load_servers()
    updated_servers = [server for server in servers if server['name'] != server_name]
    if len(updated_servers) < len(servers):
        with open('servers.json', 'w') as file:
            json.dump({'servers': updated_servers}, file, indent=4)
        await update.message.reply_text(f"Server {server_name} removed successfully!")
    else:
        await update.message.reply_text(f"Server {server_name} not found.")

async def list_servers(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List all servers (admin only)."""
    if update.effective_user.id not in ADMIN_IDS:
        return
    servers = load_servers()
    language = load_user_language(update.effective_user.id)
    if servers:
        message_text = "Server List:\n\n" if language == "en" else "Danh sách Server:\n\n"
        for server in servers:
            message_text += (
                f"<b>Name:</b> {server['name']}\n"
                f"<b>URL:</b> <code>{server['url']}</code>\n"
                f"<b>Protection:</b> {server['protection_type']}\n\n"
            )
        await update.message.reply_text(message_text, parse_mode='HTML')
    else:
        await update.message.reply_text("No servers added.", parse_mode='HTML')

async def clr(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear running servers (admin only)."""
    if update.effective_user.id in ADMIN_IDS:
        with open('server_running.json', 'w') as file:
            file.write('{}')
        await update.message.reply_text("Cleared running servers.")
    else:
        return

async def reset_rank(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Reset ranking data (admin only)."""
    if update.effective_user.id in ADMIN_IDS:
        for file in ['user_performance.json']:
            with open(file, 'w') as f:
                f.write('{}')
        await update.message.reply_text("Rankings cleared.")
    else:
        return

# Initialize bot
app = ApplicationBuilder().token("7940301420:AAGaqSn-5JE5KZzQjQ4h4CzeE9AHLvh6uZ0").build()
app.add_handler(CommandHandler("dstat", count))
app.add_handler(CommandHandler("add", add_server))
app.add_handler(CommandHandler("rm", remove_server))
app.add_handler(CommandHandler("sv", list_servers))
app.add_handler(CommandHandler("clr", clr))
app.add_handler(CommandHandler("reset", reset_rank))
app.add_handler(CallbackQueryHandler(button_callback))

print("Bot started!")
app.run_polling()
